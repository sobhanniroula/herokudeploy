<?
 require_once("../includes/my_access.php");
 require_once("../includes/functions.php");
 $winid=$_GET['window_id'];
 $lg=$_GET['lg']; if($lg=="") $lg="en";

function build_form($winid,$parentID,$lg)
{
global $showwhat;	

  $the_form=""; $js_events="";

  if($parentID=='NULL') $par_cond="parent_id IS NULL";
  else $par_cond="parent_id =".$parentID;
  $result=mysql_db_query("gui","SELECT * FROM widgets WHERE window_id='$winid' AND $par_cond");
 
 if (!$result)
 {
   $error = mysql_error();
   print ($error);
   exit;
 }

 $nbresu=mysql_num_rows($result);
 for($i=1;$i<=$nbresu;$i++)
 {
    $row = mysql_fetch_array($result);
    
 ###   $js_events.="document.getElementById('".$row["widget_id"]."').addEventListener('mousedown',beginDrag, false);\n";
    if(($row["widget_color"]!="")&&($row["widget_color"]!="transparent")&&($row["widget_color"]!="inherit")) $row["widget_color"]="#".$row["widget_color"];
    if(($row["text_color"]!="")&&($row["text_color"]!="inherit")) $row["text_color"]="#".$row["text_color"];
    if(($row["border_color"]!="")&&($row["border_color"]!="transparent")) $row["border_color"]="#".$row["border_color"];
    if(($row["image_url"]!="")&&(substr($row["image_url"],0,1)!="/")&&(substr($row["image_url"],0,7)!="http://")) $row["image_url"]="../".$row["image_url"];

    $style="position: absolute; ";
    $style.="padding: 0px; ";
    if($row["hidden"]=="N")
    {    
      $style.="left: ".$row["x"]."px; ";
      $style.="top: ".$row["y"]."px; ";
    }
    else
    {    
      $style.="left: -10000px; ";
      $style.="top: -10000px; ";
      $showwhat.="<option value=\"".$row["widget_id"]."\">wid_".$row["widget_id"]."</option>\n";
    }
    
    if($row["height"]!="")    $style.="height: ".$row["height"]."px; ";
    if($row["width"]!="")    $style.="width: ".$row["width"]."px; ";
    if($row["text_color"]!="")    $style.="color: ".$row["text_color"]."; ";
    if($row["text_size"]!="")    $style.="font-size: ".$row["text_size"]."px; ";
    if($row["text_align"]!="")    $style.="text-align: ".$row["text_align"].";";
    if($row["text_deco"]!="")    $style.="text-decoration: ".$row["text_deco"].";";
    if(($row["text_style"]!="")&&($row["text_style"]!="inherit"))
    { if(($row["text_style"]=="B")||($row["text_style"]=="BI")) $style.="font-weight: bold; "; else $style.="font-weight: normal; ";
      if(($row["text_style"]=="I")||($row["text_style"]=="BI")) $style.="font-style: italic; "; else $style.="font-style: normal; ";
    }

    if($row["widget_color"]!="")    $style.="background-color: ".$row["widget_color"]."; ";
    if($row["widget_type"]!='image')
    {
     if($row["image_url"]!="") $style.="background-image:url(".$row["image_url"].");\n";
     if($row["image_repeat"]!="") $style.="background-repeat:".$row["image_repeat"].";\n";
    }
    $style.="cursor: pointer; ";
    if($row["border_type"]!="") 
    {
     $style.="border-style: ".$row["border_type"]."; ";
     $style.="border-width: ".$row["border_top"]."px ".$row["border_right"]."px ".$row["border_bottom"]."px ".$row["border_left"]."px; ";
    }
    if($row["border_color"]!="") $style.="border-color: ".$row["border_color"]."; ";

  
    if($row["class"]!="") $class="class=\"".$row["class"]."\" ";
    else $class="";
 
    
    if($row["widget_type"]=='button')
    {
      $the_form.= "<input type=\"button\" $class name=\"".$row["widget_id"]."\" id=\"wid_".$row["widget_id"]."\" value=\"".gettext("wid_".$row["widget_id"],$lg)."\" style=\"".$style."\" onMouseOut=\"chkresizeoff(event)\" onMouseOver=\"chkresizeon(event)\">\n";
    }
    elseif($row["widget_type"]=='textarea')
    {
      $the_form.= "<textarea $class name=\"".$row["widget_id"]."\" id=\"wid_".$row["widget_id"]."\" style=\"".$style."\" onMouseOut=\"chkresizeoff(event)\" onMouseOver=\"chkresizeon(event)\" >".gettext("wid_".$row["widget_id"],$lg)."</textarea>\n";
    }
    elseif($row["widget_type"]=='text')
    {
      $the_form.= "<input type=\"text\" $class name=\"".$row["widget_id"]."\" id=\"wid_".$row["widget_id"]."\" value=\"".gettext("wid_".$row["widget_id"],$lg)."\" style=\"".$style."\" onMouseOut=\"chkresizeoff(event)\" onMouseOver=\"chkresizeon(event)\" >\n";
    }
    elseif($row["widget_type"]=='password')
    {
      $the_form.= "<input type=\"password\" $class name=\"".$row["widget_id"]."\" id=\"wid_".$row["widget_id"]."\" value=\"".gettext("wid_".$row["widget_id"],$lg)."\" style=\"".$style."\" onMouseOut=\"chkresizeoff(event)\" onMouseOver=\"chkresizeon(event)\" >\n";
    }
    elseif($row["widget_type"]=='checkbox')
    {
      $the_form.= "<input type=\"checkbox\" $class name=\"".$row["widget_id"]."\" id=\"wid_".$row["widget_id"]."\" value=\"".$row["widget_id"]."\" style=\"".$style."\">\n";
    }
    elseif($row["widget_type"]=='radio')
    {
      $the_form.= "<input type=\"radio\" $class name=\"".$row["widget_id"]."\" id=\"wid_".$row["widget_id"]."\" value=\"".$row["widget_id"]."\" style=\"".$style."\">\n";
    }
    elseif($row["widget_type"]=='select')
    {
      $the_form.="<select $class name=\"".$row["widget_id"]."\" id=\"wid_".$row["widget_id"]."\" style=\"".$style."\"\">\n";
      $res2=mysql_db_query("gui","SELECT * FROM select_source WHERE widget_id='".$row["widget_id"]."'");
      if (!$res2) { $error = mysql_error(); print ($error); exit;  }
      if ($row2 = mysql_fetch_array($res2)) $the_form.=build_select_options($link,$row2["table_name"],$row2["val_col_name"],$row2["label_col_name"],$row2["where_clause"],$row2["order_clause"]);
      $the_form.="</select>\n";
    }
    elseif($row["widget_type"]=='image')
    {
      if ($row["image_url"]!="") 
      {
           $the_form.="<img $class src=\"".$row["image_url"]."\" id=\"wid_".$row["widget_id"]."\" alt=\"".gettext("wid_".$row["widget_id"],$lg)."\" style=\"".$style."\" >";
      }
      else $the_form.="<img $class src=\"/jsdesigner/images/picicon.png\" id=\"wid_".$row["widget_id"]."\" alt=\"".gettext("wid_".$row["widget_id"],$lg)."\" style=\"".$style."\" >\n";

    } 
    elseif($row["widget_type"]=='div')
    {
      $the_form.= "<div $class id=\"wid_".$row["widget_id"]."\" style=\"".$style."\" onMouseOut=\"chkresizeoff(event)\" onMouseOver=\"chkresizeon(event)\">".gettext("wid_".$row["widget_id"],$lg)."\n";
       if(checkchhildren($row["widget_id"])>0) { $the_form.=build_form($winid,$row["widget_id"],$lg); }
       $the_form.="</div>\n";

    }
    else
    { $the_form.= "??".$row["widget_type"]."??"; }
 }
 return($the_form);
}
  

function checkchhildren($id)
{
     $res=mysql_db_query("gui","SELECT count(*) as cnt FROM widgets WHERE parent_id='$id'");
     
     if (!$res)
     {
       $error = mysql_error();
       print ($error);
       exit;
     }
     $row = mysql_fetch_array($res);

     return($row["cnt"]);
} 


$link = mysql_connect('localhost', $my_user,$my_pass) or mysql_die();

$showwhat=''; 
$the_form=build_form($winid,'NULL',$lg);


##'. $js_events.'
##document.getElementById(\'desitop\').addEventListener(\'mousedown\',beginDrag, false);

	
echo '
<html>
<head id="dbscript_parent">
 <title>Cashier</title>
 <meta http-equiv="Content-Type" content="text/HTML; charset=iso-8859-1"  />
 <link rel="stylesheet" type="text/css" href="../style.css" media="screen" title="normal" /> 

 <script language="javascript" src="/jsdesigner/js/popup.js"></script>
 <script language="javascript" src="/jsdesigner/js/dragdrop.js"></script>
 <script language="javascript" src="/jsdesigner/js/db.js"></script>
 <script language="javascript" src="/jsdesigner/js/dynatables.js"></script>

 <script id="dbscript" language="javascript" src="/jsdesigner/includes/query.js.php"></script>

</head>
<body onLoad="initit();">

<form id="morf" name="morf">
';

echo $the_form;
?>

<!-- <input type="text" size=50 id="debugit" name="debugit" value="<? echo $nbresu;?>" style="position:absolute; left:10px; top:700px;"> -->

</form>


<div id="desimain" 
style="
position:absolute; 
top:300px; 
left:500px; 
height:300px; 
width:200px; 
z-index:2000; 
background-color: #DDDDDD;
border-style: ridge;
border-width: 4px;
border-color: #CCCCCC;
font-size:12px;
" >
<div id="desitop" style="width:200px; background-color:#0000CC; color:#FFFFFF; text-align: center;
border-style: ridge; border-width: 0px 0px 3px 0px; border-color: #CCCCCC; cursor:default;">DESIGNER Console</div>

<form id="desimorf" name="desimorf">

<div style="position:absolute; top:20px; left:0px;width:80px;">
<div align="center"><b>Add widgets : </b></div>
<input id="add_button" type="button" value="button" style="position:absolute;left:10px;top:25px;height:20px;width:50px;font-size:12px;">
<input id="add_text" type="text" value="text" style="position:absolute;left:10px;top:50px;height:20px;width:50px;font-size:12px;cursor:default;">
<input id="add_pass" type="password" value="password" style="position:absolute;left:10px;top:75px;height:20px;width:50px;font-size:12px;cursor:default;">
<input type="radio" id="add_radio" style="position:absolute;left:8px;top:100px;height:13px;width:13px;background-color:transparent;" checked><div style="position:absolute;left:30px;top:105px;">Radio</div>
<input type="checkbox" id="add_check" style="position:absolute;left:9px;top:125px;width:13px;height:13px;background-color:transparent;"  checked><div style="position:absolute;left:30px;top:130px;">Check box</div>
<select id="add_select" style="position:absolute;left:10px;top:150px;height:20px;width:75px;font-size:12px;cursor:default;"><option>Selector</option></select>
<textarea id="add_ta" style="position:absolute;left:10px;top:190px;height:50px;width:50px;font-size:12px;cursor:default;">text
area</textarea>
<div id="add_div" style="position:absolute;left:70px;top:190px;width:50px;height:50px;font-size:12px;border-style:solid;border-width:2px;text-align:center;background-color:#FFFFFF;">DIV</div>
<img id="add_image" border="1" src="/jsdesigner/images/picicon.png" style="position:absolute;left:140px;top:190px;width:50px;height:50px;cursor:default;">
</div>

<div style="position:absolute; top:20px; left:87px;width:110px; height:120px; border-color: #CCCCCC; border-style: ridge; border-width: 0px 0px 4px 4px;">
<div align="center"><b>Other actions : </b></div>
<input type="radio" name="ax" checked >Move<br/>
<input type="radio" name="ax">Properties<br/>
<input type="radio" name="ax">Text/label<br/>
<input type="radio" name="ax">Delete<br/>
<input type="radio" name="ax">Action<br/>
</div>

<div style="position:absolute; top:140px; left:87px;width:110px; height:50px; border-color: #CCCCCC; border-style: ridge; border-width: 0px 0px 4px 4px;">
<div align="center" style="position:absolute; top:5px;width:110px;text-align:center;"><b>Show Hidden : </b></div>
<div align="center" style="position:absolute; top:20px;width:110px;text-align:center;">
<select name="showwhat" class="propfield" onChange="if(this.selectedIndex>0) showhidden(this.selectedIndex);">
<option value="">[select]</option>
<?echo $showwhat; ?>
</select>
</div>
</div>

<div id="dispxy" style="position:absolute; bottom:0px; left:0px; width:90px; height:20px;vertical-align:middle; border-style:solid; border-width: 1px 1px 0px 0px;text-align:left;">
&nbsp;X: 000 Y: 000
</div>
<div style="position:absolute; bottom:0px; left:110px; width:90px; height:20px; border-style:solid; border-width: 1px 0px 0px 1px;text-align:right;">
&nbsp;Gird: <input class="propfield" id="maggird" type="text" name="gird" size="3" maxlength="2" value="5" onChange="if((parseInt(this.value)==0)||(isNaN(parseInt(this.value)))){this.value=1;}"> px&nbsp;
</div>
</form>

</div>


<div id="desiprop" 
style="
position:absolute; 
top:0px; 
left:-500px; 
height:435px; 
width:300px; 
z-index:2100; 
background-color: #DDDDDD;
border-style: ridge;
border-width: 4px;
border-color: #CCCCCC;
font-size:12px;
overflow:hidden;
" >
<b><div id="proptitle" style="position:absolute;top:0px;width:300px;font-size:16px;text-align:left;background-color:#0000CC; color:#FFFFFF;border-style:solid;border-width:0px 0px 1px 0px;">
</div></b>

<form name="propmorf">

<div style="position:absolute;top:25px;">
<b>&nbsp;x,y: </b>
<input class="propfield" style="position:absolute;top:0px;left:110px;" type="text" size="5" name="x" value="xxxx">&nbsp;
<input class="propfield" style="position:absolute;top:0px;left:210px;" type="text" size="5" name="y" value="yyyy">
</div>
<div style="position:absolute;top:50px;">
<b>&nbsp;Height,Width: </b>
<input class="propfield" style="position:absolute;top:0px;left:110px;" type="text" size="5" name="h" value="xxxx">&nbsp;
<input class="propfield" style="position:absolute;top:0px;left:210px;" type="text" size="5" name="w" value="yyyy">
</div>
<div style="position:absolute;top:75px;">
<b>&nbsp;Bachground Color: </b>
<input class="propfield" style="position:absolute;top:0px;left:110px;" type="text" name="color" size="8" maxlegnth=6 value="FFFFFF">
</div>
<div style="position:absolute;top:100px;">
<b>&nbsp;Text Size: </b>
<select class="propfield" style="position:absolute;top:0px;left:110px;" name="txtsize">
<option value="6">6px</option>
<option value="8">8px</option>
<option value="10">10px</option>
<option value="12">12px</option>
<option value="14">14px</option>
<option value="16">16px</option>
<option value="18">18px</option>
<option value="20">20px</option>
<option value="22">22px</option>
<option value="24">24px</option>
<option value="32">32px</option>
<option value="48">48px</option>
<option value="72">72px</option>
</select>
</div>
<div style="position:absolute;top:125px;">
<b>&nbsp;Text Color: </b>
<input class="propfield" style="position:absolute;top:0px;left:110px;" type="text" name="txtcolor" size="8" maxlegnth=6 value="FFFFFF"><br>
</div>

<div style="position:absolute;top:150px;">
<b>&nbsp;Text-align: </b>
<select class="propfield" style="position:absolute;top:0px;left:110px;" name="txtalign">
<option value="inherit">Inherit</option>
<option value="left">Left</option>
<option value="right">Right</option>
<option value="center">Center</option>
<option value="justify">Justify</option>
</select>
</div>
<div style="position:absolute;top:175px;">
<b>&nbsp;Text deco./style: </b>
<select class="propfield" style="position:absolute;top:0px;left:110px;" name="txtdecoration">
<option value="inherit">Inherit</option>
<option value="none">None</option>
<option value="underline">Underline</option>
<option value="overline">Overline</option>
<option value="line-through">Line-through</option>
<option value="blink">Blink</option>
</select>
<select class="propfield" style="position:absolute;top:0px;left:210px;" name="txtstyle">
<option value="inherit">Inherit</option>
<option value="N">Normal</option>
<option value="B">Bold</option>
<option value="I">Italic</option>
<option value="BI">Bold & Italic</option>
</select>
</div>


<div style="position:absolute;top:200px;">
<b>&nbsp;Border Type: </b>
<select class="propfield" style="position:absolute;top:0px;left:110px;" name="bordertype">
<option value="">Default</option>
<option value="none">None</option>
<option value="dotted">Dotted</option>
<option value="dashed">Dashed</option>
<option value="solid">Solid</option>
<option value="double">Double</option>
<option value="groove">Groove</option>
<option value="ridge">Ridge</option>
<option value="inset">Inset</option>
<option value="outset">Outset</option>
</select>
</div>
<div style="position:absolute;top:225px;">
<b>&nbsp;Border size: </b>
<div style="position:absolute;top:0px;left:86px;">Left: <input class="propfield" type="text" name="bsl" size="2" maxlegnth="2" value="1"></div>
<div style="position:absolute;top:0px;left:192px;">Right: <input class="propfield" type="text" name="bsr" size="2" maxlegnth="2" value="1"></div>
<div style="position:absolute;top:25px;left:86px;">Top: <input class="propfield" type="text" name="bst" size="2" maxlegnth="2" value="1"></div>
<div style="position:absolute;top:25px;left:180px;">Bottom: <input class="propfield" type="text" name="bsb" size="2" maxlegnth="2" value="1"></div>
</div>

<div style="position:absolute;top:275px;">
<b>&nbsp;Border Color: </b>
<input class="propfield" style="position:absolute;top:0px;left:110px;" type="text" name="bordcolor" size="8" maxlegnth="6" value="FFFFFF"><br>
</div>

<div style="position:absolute;top:300px;" id="bgimageurl">
<b>&nbsp;Image URL: </b>
<input class="propfield" style="position:absolute;top:0px;left:110px;" type="text" name="bgimage" size="35" maxlegnth="255" value=""><br>
</div>

<div style="position:absolute;top:325px;" id="bgimagerepeat">
<b>&nbsp;Bg-Image Repeat: </b>
<select class="propfield" style="position:absolute;top:0px;left:110px;" name="bgrepeat">
<option value="repeat">Repeat XY</option>
<option value="repeat-x">Repeat X</option>
<option value="repeat-y">Repeat Y</option>
<option value="no-repeat">No Repeat</option>
</select>
</div>

<div style="position:absolute;top:350px;color:#AA0000;" >
<b>&nbsp;HIDDEN WIDGET: </b>
<input type="checkbox" style="position:absolute;top:0px;left:110px;" name="hidden" id="hidden">
</div>

<div style="position:absolute;top:375px;color:#AA0000;" >
<b>&nbsp;PARENT WIDGET: </b>
<select class="propfield" style="position:absolute;top:0px;left:110px;" name="parent" id="parentid">
<option value="morf">Main Window</option>
</select>
</div>

<div style="position:absolute;bottom:5px;width:300px;text-align:center;">
<input  type="button" name="ok" value="OK" onClick="endprop(1);">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input  type="button" name="cancel" value="Cancel" onClick="endprop(0);">
</div>
</form>

</div>



<div id="desitxtprop" 
style="
position:absolute; 
top:0px; 
left:-300px; 
height:250px; 
width:270px; 
z-index:2100; 
background-color: #DDDDDD;
border-style: ridge;
border-width: 4px;
border-color: #CCCCCC;
font-size:12px;
" >
<b><div id="proptxttitle" style="position:absolute;top:0px;width:270px;font-size:16px;text-align:left;background-color:#0000CC; color:#FFFFFF;border-style:solid;border-width:0px 0px 1px 0px;">
</div></b>

<form name="proptxtmorf">


<div style="overflow:auto;position:absolute;top:25px;width:265px;height:190px;">
<b>&nbsp;Labels : </b>
<table id="txtlabeltable" style="position:absolute;top:20px;left:10px;font-size:14px;text-align:left;background-color:#AAAAFF; color:#000000;border-style:solid;border-color:#0000AA;border-width:1px 1px 1px 1px;">
<tr style="font-size:14px;text-align:center;background-color:#0000AA; color:#FFFFFF;">
<td>Language</td><td>Label</td><td>&nbsp;</td></tr>
</table>
</div>


<div style="position:absolute;bottom:5px;width:250px;text-align:center;">
<input  type="button" name="ok" value="OK" onClick="endtxtprop(1);">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input  type="button" name="Cancel" value="CANCEL" onClick="endtxtprop(0);">
</div>

</form>

</div>


<div id="desiaction" 
style="
position:absolute; 
top:10px; 
left:-1000px; 
height:550px; 
width:700px; 
z-index:2100; 
background-color: #DDDDDD;
border-style: ridge;
border-width: 4px;
border-color: #CCCCCC;
font-size:12px;
" >

<b><div id="actiontitle" style="position:absolute;top:0px;width:700px;font-size:16px;text-align:left;background-color:#0000CC; color:#FFFFFF;border-style:solid;border-width:0px 0px 1px 0px;">
&nbsp;</div></b>

<form name="actionmorf">

<div style="position:absolute;left:10px; top:25px;">
<b>&nbsp;Event: </b>
<select class="propfield" style="position:absolute;top:0px;left:80px;" name="actevent" onChange="selectaction(this.selectedIndex);">
<option value="">[Select an Event]</option>
<option value="blur">Blur</option>
<option value="change">Change</option>
<option value="click">Click</option>
<option value="dblclick">Double Click</option>
<option value="focus">Focus</option>
<option value="keydown">Key Down</option>
<option value="keypress">Key Press</option>
<option value="keyup">Key Up</option>
<option value="mousedown">Mouse Down</option>
<option value="mousemove">Mouse Move</option>
<option value="mouseout">Mouse Out</option>
<option value="mouseover">Mouse Over</option>
<option value="mouseup">Mouse Up</option>
<option value="select">Select text</option>
</select>
</div>

<div  style="position:absolute;left:10px; top:50px;">
<textarea id="action" name="action" style="width:680px;height:450px;">
</textarea>
</div>

<div style="position:absolute;bottom:5px;width:700px;text-align:center;">
<input  type="button" name="ok" value="OK" onClick="endaction(1);">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input  type="button" name="Cancel" value="CANCEL" onClick="endaction(0);">
</div>

</form>

</div>

<!--<div id="marquee" style="position:absolute;top:0px;left:-10px;width:0px;height:0px;border-style:dashed;border-width:1px;"></div>-->
</html>