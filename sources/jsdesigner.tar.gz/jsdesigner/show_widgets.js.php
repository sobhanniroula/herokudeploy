<?
 require_once("includes/my_access.php");
 require_once("includes/functions.php");

 $winid=$_GET['window_id'];
 $lg=$_GET['lg']; if($lg=="") $lg="en";

function show_widgets($winid,$parentID,$lg)
{
global $functions;
	
  if($parentID=='NULL') $par_cond="parent_id IS NULL";
  else $par_cond="parent_id =".$parentID;
  $result=mysql_db_query("gui","SELECT * FROM widgets WHERE window_id='$winid' AND $par_cond");

  if (!$result) { $error = mysql_error();  print ($error);  exit;  }
  

  while($row = mysql_fetch_array($result))
  {
     $res2=mysql_db_query("gui","SELECT * FROM actions WHERE widget_id='".$row["widget_id"]."'");
     if (!$res2) { $error = mysql_error();  print ($error);  exit;  }
  	
     while($row2 = mysql_fetch_array($res2))
     { 
       $fnname="wid_".$row["widget_id"]."_".$row2["type"];
       $functions.="\nfunction ".$fnname."(e)\n{ if (!e) var e = window.event;\n";
       $functions.=rawurldecode($row2["function"]);
       $functions.="\n}\n";
###       echo "document.getElementById('wid_".$row["widget_id"]."').addEventListener('".$row["type"]."',".$fnname.",false);\n";
       echo "document.getElementById('wid_".$row["widget_id"]."').on".$row2["type"]."=".$fnname.";\n";

     }
     if($row["widget_type"]=='div')
     { 
       if(checkchhildren($row["0"])>0) { show_widgets($winid,$row["0"],$lg); }
     }
  }
  	

}

function checkchhildren($id)
{
     $res=mysql_db_query("gui","SELECT count(*) as cnt FROM widgets WHERE parent_id='$id'");
     
     if (!$res)
     {
       $error = mysql_error();
       print ($error);
       exit;
     }
     $row = mysql_fetch_array($res);

     return($row["cnt"]);
}

$link = mysql_connect('localhost', $my_user,$my_pass) or mysql_die();

##### Now add the subwindows #####

$res=mysql_db_query("gui","SELECT * FROM subwindows WHERE parent_id='$winid'");
     
if (!$res)
{
  $error = mysql_error();
  print ($error);
  exit;
}
$nbsubwin=0;

while($sw_row[$nbsubwin] = mysql_fetch_array($res)) $nbsubwin++;

$functions='';
echo "function Form_Init()\n{\n";
show_widgets($winid,'NULL',$lg);


##### Subwindows #####

for($i=0;$i<$nbsubwin;$i++)
{
  show_widgets($sw_row[$i]["id"],'NULL',$lg);
}



##### Main window (requested in URL) #####
echo "}\n";
echo $functions;


?>