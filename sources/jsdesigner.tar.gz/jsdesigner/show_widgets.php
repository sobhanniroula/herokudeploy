<?
 require_once("includes/my_access.php");
 require_once("includes/functions.php");
 

$winid=$_GET['window_id'];
 $mainwinid=$winid;
 $lg=$_GET['lg']; if($lg=="") $lg="en";

function show_widgets($winid,$parentID,$lg)
{
global $mainwinid;
$swout="";

  if($parentID=='NULL') $par_cond="parent_id IS NULL";
  else $par_cond="parent_id =".$parentID;
  $result=mysql_db_query("gui","SELECT * FROM widgets WHERE window_id='$winid' AND $par_cond");

  if (!$result)
  {
    $error = mysql_error();
    print ($error);
    exit;
  }
  
  $nbresu=mysql_num_rows($result);
  for($i=1;$i<=$nbresu;$i++)
  {
     $row = mysql_fetch_array($result);
  
     if($row["class"]!="") $class="class=\"".$row["class"]."\" ";
     else $class="";

   ################## Build style #################
   $style="";

   if(($row["widget_color"]!="")&&($row["widget_color"]!="transparent")&&($row["widget_color"]!="inherit")) $row["widget_color"]="#".$row["widget_color"];
   if(($row["text_color"]!="")&&($row["text_color"]!="inherit")) $row["text_color"]="#".$row["text_color"];
   if(($row["border_color"]!="")&&($row["border_color"]!="transparent")) $row["border_color"]="#".$row["border_color"];

   $style.= "position: absolute;";
   $style.= "padding: 0px;";
   if( ($row["parent_id"]!="") || (($row["hidden"]=='N') && ($winid===$mainwinid)))
   {
    $style.= "left: ".$row["x"]."px;";
    $style.= "top: ".$row["y"]."px;";
   }
   else
   {
    $style.= "left: -10000px;";
    $style.= "top: -10000px;";
   }
  
   if($row["height"]!="") $style.= "height: ".$row["height"]."px;";
   if($row["width"]!="") $style.= "width: ".$row["width"]."px;";
   if($row["text_color"]!="") $style.= "color: ".$row["text_color"].";";
   if($row["text_size"]!="")        $style.= "font-size: ".$row["text_size"]."px;";
   if($row["text_align"]!="")    $style.= "text-align: ".$row["text_align"].";";
   if($row["text_deco"]!="")    $style.= "text-decoration: ".$row["text_deco"].";";
   if(($row["text_style"]!="")&&($row["text_style"]!="inherit"))
   { if(($row["text_style"]=="B")||($row["text_style"]=="BI")) $style.= "font-weight: bold;"; else $style.= "font-weight: normal;";
     if(($row["text_style"]=="I")||($row["text_style"]=="BI")) $style.= "font-style: italic;"; else $style.= "font-style: normal;";
   }
   if($row["widget_color"]!="")     $style.= "background-color: ".$row["widget_color"].";";
   if($row["widget_type"]!='image')
   {
     if($row["image_url"]!="") $style.= "background-image:url(".$row["image_url"].");";
     if($row["image_repeat"]!="") $style.= "background-repeat:".$row["image_repeat"].";";
   }
   
   if($row["border_type"]!="") 
   {
    $style.= "border-style: ".$row["border_type"].";";
    $style.= "border-width: ".$row["border_top"]."px ".$row["border_right"]."px ".$row["border_bottom"]."px ".$row["border_left"]."px;";
   }
   if($row["border_color"]!="") $style.= "border-color: ".$row["border_color"].";";

   if($row["tab_index"]!="") $tabindex= "tabindex=\"".$row["tab_index"]."\""; else $tabindex="";
   ################## End of style #################


     if($row["widget_type"]=='button')
     {
       $swout.="<input $tabindex $class type=\"button\" name=\"".$row["widget_id"]."\" id=\"wid_".$row["widget_id"]."\" value=\"".gettext("wid_".$row["widget_id"],$lg)."\" style=\"$style\" >\n";
     }
     elseif($row["widget_type"]=='textarea')
     {
       $swout.= "<textarea $tabindex $class name=\"".$row["widget_id"]."\" id=\"wid_".$row["widget_id"]."\" style=\"$style\" ></textarea>\n";
     }
     elseif($row["widget_type"]=='text')
     {
       $swout.= "<input $tabindex $class type=\"text\" name=\"".$row["widget_id"]."\" id=\"wid_".$row["widget_id"]."\" value=\"".gettext("wid_".$row["widget_id"],$lg)."\" style=\"$style\" >\n";
     }
     elseif($row["widget_type"]=='password')
     {
       $swout.= "<input $tabindex $class type=\"password\" name=\"".$row["widget_id"]."\" id=\"wid_".$row["widget_id"]."\" value=\"".gettext("wid_".$row["widget_id"],$lg)."\" style=\"$style\" >\n";
     }
     elseif($row["widget_type"]=='checkbox')
     {
       $swout.= "<input $tabindex $class type=\"checkbox\" name=\"".$row["widget_id"]."\" id=\"wid_".$row["widget_id"]."\" value=\"".$row["widget_id"]."\" style=\"$style\" >\n";
     }
     elseif($row["widget_type"]=='radio')
     {
       $swout.= "<input $tabindex $class type=\"radio\" name=\"".$row["widget_id"]."\" id=\"wid_".$row["widget_id"]."\" value=\"".$row["widget_id"]."\" style=\"$style\" >\n";
     }
     elseif($row["widget_type"]=='select')
     {
       $swout.= "<select $tabindex $class name=\"".$row["widget_id"]."\" id=\"wid_".$row["widget_id"]."\" style=\"$style\" >\n";
       $res2=mysql_db_query("gui","SELECT * FROM select_source WHERE widget_id='".$row["widget_id"]."'");
       if (!$res2) { $error = mysql_error(); print ($error); exit;  }
       if ($row2 = mysql_fetch_array($res2)) $swout.= build_select_options($link,$row2["table_name"],$row2["val_col_name"],$row2["label_col_name"],$row2["where_clause"],$row2["order_clause"]);
       $swout.= "</select>\n";
     }
     elseif($row["widget_type"]=='image')
     {
       if ($row["image_url"]!="") $swout.= "<img $class src=\"".$row["image_url"]."\" id=\"wid_".$row["widget_id"]."\" alt=\"".gettext("wid_".$row["widget_id"],$lg)."\" style=\"$style\" >\n";
       else $swout.= "<img $class src=\"images/brokenpic.gif\" id=\"wid_".$row["widget_id"]."\" alt=\"".gettext("wid_".$row["widget_id"],$lg)."\" style=\"$style\" >\n";
     }     
     elseif($row["widget_type"]=='div')
     {
       $swout.= "<div $class id=\"wid_".$row["widget_id"]."\" style=\"$style\" >".gettext("wid_".$row["widget_id"],$lg)."\n";
       if(checkchhildren($row["widget_id"])>0) { $swout.= show_widgets($winid,$row["widget_id"],$lg); }
       $swout.= "</div>\n";
     }
     else
     { $swout.= "???"; }
     unset($row);
  }
  	
return($swout);
}

function checkchhildren($id)
{
     $res=mysql_db_query("gui","SELECT count(*) as cnt FROM widgets WHERE parent_id='$id'");
     
     if (!$res)
     {
       $error = mysql_error();
       print ($error);
       exit;
     }
     $row = mysql_fetch_array($res);

     return($row["cnt"]);
}


####################################################################################################

$link = mysql_connect('localhost', $my_user,$my_pass) or mysql_die();


##### First, get the xhtml template #####
$res=mysql_db_query("gui","SELECT * FROM window_templates WHERE window_id='$winid'");
     
if (!$res) { $error = mysql_error(); print ("GETTING TEMPLATE: ".$error); exit; }
if(!($row = mysql_fetch_array($res))) 
{ 
 $win_template="
<html><head><title>TEST TEMPLATE</title><meta http-equiv=\"Content-Type\" content=\"text/HTML; charset=iso-8859-1\"  />

 _#FORM_STYLES#_
 
 _#FORM_SCRIPTS#_ 
 
</head>
<body onload=\"Form_Init();alert('No template was found for this window !?\\nIt is normal if this is a subwindow, otherwise you need to add one in window_templates\\nUsing DEFAULT TEST template...');\">

_#FORM_CONTENT#_

</html>

";
}
else $win_template=$row["template"];

##### Now get & add the subwindows #####

$res=mysql_db_query("gui","SELECT * FROM subwindows WHERE parent_id='$winid'");
     
if (!$res) { $error = mysql_error(); print ("GETTING SUBWINDOWS: ".$error); exit; }
$nbsubwin=0;
while($sw_row[$nbsubwin] = mysql_fetch_array($res)) $nbsubwin++;

##### build the dynamic style #####
### $dyna_styles='<link rel="stylesheet" type="text/css" href="show_widgets.css.php?window_id='.$winid.'" media="screen" title="normal" /> '."\n";
###
### ##### Subwindows CSS #####
###
### for($i=0;$i<$nbsubwin;$i++)
### {
###  $dyna_styles.= '<link rel="stylesheet" type="text/css" href="show_widgets.css.php?window_id='.$sw_row[$i]["id"].'&hide='.$sw_row[$i]["base_widget_id"].'" media="screen" title="normal" />'."\n";
### }


##### build the dynamic JS #####
$dyna_js='<script language="javascript" src="show_widgets.js.php?window_id='.$winid.'"></script>'."\n";

##### build the dynamic form #####
 ##### start with main window (requested in URL) #####
$dyna_form="<form name=\"".$winid."\">\n";

$dyna_form.=show_widgets($winid,'NULL',$lg);

 ##### Subwindows #####

 for($i=0;$i<$nbsubwin;$i++)
 {
   $dyna_form.=show_widgets($sw_row[$i]["id"],'NULL',$lg);
 }



###$dyna_form.="<input type=\"text\" name=\"debugit\" id=\"debugit\" length=\"132\" style=\"position:absolute;top:700px;left:0px;\"/>\n";
$dyna_form.="</form>\n";

##### Do replacement & print #####

###$win_template=str_replace("_#FORM_STYLES#_",$dyna_styles,$win_template);
$win_template=str_replace("_#FORM_STYLES#_","",$win_template);
$win_template=str_replace("_#FORM_SCRIPTS#_",$dyna_js,$win_template);
$win_template=str_replace("_#FORM_CONTENT#_",$dyna_form,$win_template);
echo $win_template;
?>
