<?

function gettext($id,$lg)
{
global $gettext_tab;

####### do caching stuff #######
if(! isset($gettext_tab))
{
   $result=mysql_db_query("gui","SELECT id,label FROM getxt where lg='$lg'");
   
   if (!$result)
   {
     $error = mysql_error();
     print ($error);
     exit;
   }

   $nbresu=mysql_num_rows($result);
   for($i=1;$i<=$nbresu;$i++)
   {
      $row = mysql_fetch_array($result);
      $gettext_tab[$row["id"]]=preg_replace("/%u([A-F0-9]+)/e","'&#'.hexdec('\\1').';'",$row["label"]);
      #### Waouw, this is great, I love PHP !
   }	
}
######  end of caching stuff ######
$res=$gettext_tab[$id];
if($res=='') 
{ ##return($id); 
  return(""); 
}
else return($res);
	
}

function build_select_options($link,$tbl,$col_val,$col_name,$where="1=1",$order="1=1")
{
 $opt="<option value=\"\" selected></option>\n";
 if($where=="") $where="1=1";
 if($order!="") $order="ORDER BY ".$order;
   $result=mysql_db_query("gui","SELECT * FROM ".$tbl." WHERE ".$where." ".$order);
   
   if (!$result)
   {
     $error = mysql_error();
     print ($error);
     exit;
   }
   
 while ($row = mysql_fetch_array($result)) 
 {
   $opt.="<option value=\"".$row[$col_val]."\">".$row[$col_name]."</option>\n";
 }
 return($opt); 
}

function toentities ($string)
{
        $string=htmlentities($string);
        $string=str_replace("'","&#039;",$string);	
}

function fromentities ($string)
{
        $string=str_replace("&#039;","'",$string);	
	$trans_tbl = get_html_translation_table (HTML_ENTITIES);
	$trans_tbl = array_flip ($trans_tbl);
	return strtr ($string, $trans_tbl);
}

	
?>