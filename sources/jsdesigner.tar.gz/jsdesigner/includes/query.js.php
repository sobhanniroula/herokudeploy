<?
 require_once("my_access.php");


$debug=0;



$link = mysql_connect('localhost',$my_user,$my_pass) or mysql_die();

$query=rawurldecode($_GET["query"]);
if($query=="") exit;
$query=str_replace("\'","'",$query);

$db=rawurldecode($_GET["db"]);
if($db=="") $db="gui";
$db=str_replace("\'","'",$db);



$result=mysql_db_query($db,$query);

$disp="";
$error="";
if (!$result)
{
  $error = mysql_error();
  $error.="\\n in query:\\n".$query;
}
else
{

  $query_cmd=substr(strtolower($query),0,6);

  if($query_cmd=="select")
  {
   $nbresu=mysql_num_rows($result);
   $disp.="nbresults=".$nbresu.";";

   $disp.="tab=new Array(".$nbresu.");\n";
   for($i=0;$i<$nbresu;$i++)
   {
      $row = mysql_fetch_array($result,MYSQL_ASSOC);
      $disp.="tab[".$i."]=new Array("; 	
      foreach ($row as $field=>$val)
      {
        $disp.="'".$val."',"; 	
      }
      $disp=substr($disp,0,strlen($disp)-1); $disp.=");\n";
   }
  }
  elseif($query_cmd=="insert")
  {
  	    $disp.="inserted_id='".mysql_insert_id()."';\n";
  }

}
if($error!="")
{ $newerr="";
  for($i=0;$i<strlen($error);$i+=70)
  {

   if(($i+69)<strlen($error)) $chunk=substr($error,$i,70);
   else $chunk=substr($error,$i);

   $newerr.=$chunk."\\n";
  }
  $disp.="query_err='".str_replace("'","\'",$newerr)."';";
}
else
{
  $disp.="query_err='';\n";
}

if($debug>0)
{ $newdebug="DEBUG:\\nQUERY=";
  $debug=$query;
  for($i=0;$i<strlen($debug);$i+=70)
  {

   if(($i+69)<strlen($debug)) $chunk=substr($debug,$i,70);
   else $chunk=substr($debug,$i);

   $newdebug.=$chunk."\\n";
  }
  $disp.="query_debug='".str_replace("'","\'",$newdebug)."';";
}
else
{
  $disp.="query_debug='';\n";
}

echo $disp;
echo "response_arrived=true;\n"; ### always put me at the end !!
exit;
?>