<?
##### Change the lines below to user that has SELECT/INSERT/UPDATE/DELETE priviledges on the "gui" database

 $my_user='jsdesigner';
 $my_pass='1234';
?>