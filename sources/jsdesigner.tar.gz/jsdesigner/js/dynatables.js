
function getObj(name)
{
  if (document.getElementById)
  {
  	this.obj = document.getElementById(name);
	this.style = document.getElementById(name).style;
  }
  else if (document.all)
  {
	this.obj = document.all[name];
	this.style = document.all[name].style;
  }
  else if (document.layers)
  {
   	this.obj = document.layers[name];
   	this.style = document.layers[name];
  }
}


function del_tbl_line(id,linenb)
{
	var tbl = new getObj(id);
	tblobj=tbl.obj;
	tblbod=tblobj.tBodies[0];
	tblbod.removeChild(tblobj.rows[linenb]);
}

function add_tbl_lines(id,value_tab,keep)
// WARNING : For this function to work properly,
// !!!!!!! TABLE MUST BE ALONE IN ITS PARENT TAG !!!!!!!
// This is because of fucking IE which doesn't allow for innerHTML assignment inside a table
// so we need to work with the whole table at once from the parent, 
// I didn't bother to build up a complicated logic to find out the table begin & end if several tables are present.
// So just make the table as the only content of a <div>, it makes this function much faster as well.
// YES I KNOW, it doesn't really use DOM, this is because it would be slower, & incompatible with fucking IE-MAC
// PARAMS :
// id               : the id of the div containing the table (as direct child)
// value_tab        : either a 2D array : tab[rows-index][cols-index] : to add several lines
//                    or a vector   : tab[cols-index] : to add 1 line
// keep : 'nothing' : all rows including the 1st are removed, value_tab is then appended. 
//                    (<table> tag is kept to keep existing style/class/id)
//        'header'  : first row is kept (header), rest is removed, value_tab is then appended.
//        'all'     : all existing rows are kept, value_tab is appended
//        line_nb   : inserted after line_nb
{
	var tbl = new getObj(id);
	var tbl_parent=tbl.obj.parentNode;
	
	curtbl=tbl_parent.innerHTML;
/// alert('before\n'+curtbl);       
        added='';
	maxrow=value_tab.length;

	if (typeof(value_tab[0])=='string')// 1 dimension array (vector)
	{
	    added+='<tr>';
	    for(i=0;i<maxrow;i++)
	    {
	      	added+='<td>'+value_tab[i]+'</td>';
	    }
	    added+='</tr>';	
	} 
	else // 2 dimensions array
	{ 
	  maxcol=value_tab[0].length;
	  for(i=0;i<maxrow;i++)
	  { added+='<tr>';
	    for(j=0;j<maxcol;j++)
	    {
	      	added+='<td>'+value_tab[i][j]+'</td>';
	    }
	    added+='</tr>';
	  }
	}
	
	if(keep=='nothing')
	{ 
          i=curtbl.indexOf('<tbody>');
          if(i==-1) i=curtbl.indexOf('<TBODY>'); ///fucking IE is not even (internally) xhtml compliant !
          curtbl=curtbl.substr(0,i+7);
	}
	else if(keep=='header')
	{ 
          i=curtbl.indexOf('</th>');
          if(i==-1) i=curtbl.indexOf('</TH>');
          if(i==-1) i=curtbl.indexOf('</tr>');
          if(i==-1) i=curtbl.indexOf('</TR>');
          curtbl=curtbl.substr(0,i+5);		
	}
	else if(keep=='all')
	{ 
          i=curtbl.lastIndexOf('</tbody>');
          if(i==-1) i=curtbl.lastIndexOf('</TBODY>'); ///fucking IE is not even (internally) xhtml compliant !
          curtbl=curtbl.substr(0,i);
        }
        else if(line_nb=parseInt(keep)) 
        {
          i=curtbl.indexOf('<tbody>');
          if(i==-1) i=curtbl.indexOf('<TBODY>'); ///fucking IE is not even (internally) xhtml compliant !
          newtbl=curtbl.substr(0,i+7);

          oldi=i+7;

          if(line_nb<0) line_nb=0;
          i=curtbl.indexOf('</tr>');
          if(i==-1) i=curtbl.indexOf('</TR>');
          j=0;
          while((i>-1)&&(j<line_nb))
          { 
            newtbl+='\n'+curtbl.substring(oldi,i+5);
            j++; oldi=i+5;		
            i=curtbl.indexOf('</tr>',oldi);
            if(i==-1) i=curtbl.indexOf('</TR>',oldi);
          }   
          added+=curtbl.substring(oldi);
          curtbl=newtbl;

        }

        tbl_parent.innerHTML = curtbl+added+'</tbody></table>';
}


