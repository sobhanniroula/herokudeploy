var current_win='designer';
var marq_start_x,marq_start_y;
var detect_resize_width=3;

  function initit()
  {
   window.onmousedown=mouseclick;
   response_arrived=true;
   getUrlParams();
   document.oncontextmenu=rightclick;
  }
  
  function getUrlParams()
  {
   urlParams = new Object();
   for (i = 0; p = window.location.search.split('&')[i]; i++) {if (/\??(.*)=(.*)/.test(p)) urlParams[unescape(RegExp.$1)] = unescape(RegExp.$2)}
  }

  function rightclick(e)
  {     if(over_desimain(e.clientX,e.clientY)) return false;
        ////////// Check where we've landed (only divs)
        over_what(e.clientX,e.clientY); // get everything under this position
        maxdepth=0; widget=null; 
        for(i=0;i<over_nodes.length;i++) 
        { 
             if(over_nodes_depths[i]>maxdepth) { maxdepth=over_nodes_depths[i]; widget=over_nodes[i]; }
        }   	
        if(widget)
        {
  	 widget_id=widget.id;adding=false;
  	 showprops(e.clientX,e.clientY,widget_id);
  	}
  	return false;
  }
//-------------------------------------------------------------------------------------
// doResize event 
function doResize(e) {

	// Calculates the difference between the last mouse position
	// and the current position. 
	//
        //var difX=e.clientX-window.lastX;
        //var difY=e.clientY-window.lastY;
        var difX=e.clientX-window.lastX;
        var difY=e.clientY-window.lastY;
	// Retrieves the x and y position for the widget and adding 
	// the dif value.

	// Sets the new size 
        if(resizing=='se') 
        {
           var newW = parseInt(document.getElementById(widget_id).style.width,10)+difX;
           var newH = parseInt(document.getElementById(widget_id).style.height,10)+difY;
           document.getElementById(widget_id).style.width=newW+"px"; document.getElementById(widget_id).style.height=newH+"px"; 
        }
        else if(resizing=='e') 
        { 
           var newW = parseInt(document.getElementById(widget_id).style.width,10)+difX;
           var newH = parseInt(document.getElementById(widget_id).style.height,10);
           document.getElementById(widget_id).style.width=newW+"px";
        }
        else if(resizing=='s')
        {
          var newW = parseInt(document.getElementById(widget_id).style.width,10);
          var newH = parseInt(document.getElementById(widget_id).style.height,10)+difY;
          document.getElementById(widget_id).style.height=newH+"px";
        }
        document.getElementById('dispxy').innerHTML='&nbsp;W: '+newW+' H: '+newH;

	// Stores the current mouse position.
	//
        window.lastX=e.clientX;
        window.lastY=e.clientY;
}
function endResize(e) {
	gird=parseInt(document.desimorf.gird.value,10);
	// Snap to gird
        var newW = gird*Math.round(parseInt(document.getElementById(widget_id).style.width,10)/gird);
        var newH = gird*Math.round(parseInt(document.getElementById(widget_id).style.height,10)/gird);

        document.getElementById(widget_id).style.width=newW+"px";
        document.getElementById(widget_id).style.height=newH+"px";


        query="UPDATE widgets SET width="+newW+",height="+newH+" WHERE widget_id="+widget_id.substr(4);
        do_query(query,'');


	// Releases the onmousemove event.
        window.onmousemove=null;
        window.onmouseup=null;
        window.onmousedown=mouseclick;
        document.getElementById(widget_id).onmouseover=chkresizeon;
        document.getElementById(widget_id).onmouseout=chkresizeoff;


}

function chkresizeon(e)
{
 e.target.onmousemove=chkresize;
}
function chkresizeoff(e)
{
 e.target.onmousemove=null;
}
//-------------------------------------------------------------------------------------
// doDrag event - called when dragging
function doDrag(e) {
	
	// Calculates the difference between the last mouse position
	// and the current position. 
	//
        //var difX=e.clientX-window.lastX;
        //var difY=e.clientY-window.lastY;
        var difX=e.clientX-window.lastX;
        var difY=e.clientY-window.lastY;

	// Retrieves the x and y position for the widget and adding 
	// the dif value.
        // h=1*document.getElementById(widget_id).style.height.substr(0,document.getElementById(widget_id).style.height.length-2);
        var newX1 = parseInt(document.getElementById(widget_id).style.left,10)+difX;
        var newY1 = parseInt(document.getElementById(widget_id).style.top,10)+difY;

        if(widget_id!='desimain') document.getElementById('dispxy').innerHTML='&nbsp;X: '+newX1+' Y: '+newY1;
        //if(widget_id!='desimain') document.getElementById('dispxy').innerHTML='&nbsp;X: '+newX1+' Y: '+(e.clientX-);

	// Sets the new position 
        document.getElementById(widget_id).style.left=newX1+"px";
        document.getElementById(widget_id).style.top=newY1+"px";

	// Stores the current mouse position.
	//
        window.lastX=e.clientX;
        window.lastY=e.clientY;
}

//----------------------------------------------------------------------------
// Called when the mouse button is released
function endDrag(e) {
//alert(e.target.getAttribute("ID"));	
	gird=parseInt(document.desimorf.gird.value,10);
	// Snap to gird
        var newX1 = gird*Math.round(parseInt(document.getElementById(widget_id).style.left,10)/gird);
        var newY1 = gird*Math.round(parseInt(document.getElementById(widget_id).style.top,10)/gird);

        document.getElementById(widget_id).style.left=newX1+"px";
        document.getElementById(widget_id).style.top=newY1+"px";
        if(widget_id!='desimain') document.getElementById('dispxy').innerHTML='&nbsp;X: '+newX1+' Y: '+newY1;
       
	if((widget_id!='desimain') && (document.desimorf.ax[0].checked))
	{ 
           document.getElementById(widget_id).style.zIndex='auto';

           ////////// Check where we've landed (only divs)
           over_what(e.clientX,e.clientY); // get everything under this position
           maxdepth=0; n=document.getElementById('morf');
           for(i=0;i<over_nodes.length;i++) 
           { 
              if((over_nodes[i].nodeName.toLowerCase()=='div')&&(over_nodes[i].id!=widget_id)) // only take divs and not current one
              { // if several cascaded divs, take the smallest child = max depth
                if(over_nodes_depths[i]>maxdepth) { maxdepth=over_nodes_depths[i]; n=over_nodes[i]; }
              }
           }           
           
           if(adding)
           { if(over_desimain(newX1,newY1)) //Check if new item was not dropped on designer window
             { alert('If you want to drop an element there,\nplease move the designer window first !'); 
               objecttodestroy = document.getElementById(widget_id);
               document.morf.removeChild(objecttodestroy);             
             }
             else
             {
             	 if(maxdepth>0)
             	 { //alert('You have dropped the widget over a DIV ('+n.id+')\nThe widget will be created inside (as a child of) it.\nYou can change this in the widget properties\n');
             	 
                   var om = document.getElementById(widget_id);
                   var absX=e.clientX;
                   var absY=e.clientY;
                   //alert('original xy:'+absX+','+absY+' mouse='+e.clientX+','+e.clientY+' delta='+mouse2corner_x+','+mouse2corner_y);
                   var pn=n;
                   while(pn.id!='morf')
                   {
                   	 //alert('xy:'+absX+','+absY+' parentXY:'+parseInt(pn.style.left,10)+','+parseInt(pn.style.top,10)+'('+pn.id+')');
                   	 absX-=parseInt(pn.style.left,10);
                   	 absY-=parseInt(pn.style.top,10);  
                   	 pn=pn.parentNode;             	 
                   }
                   absX=gird*Math.round(absX/gird);
                   absY=gird*Math.round(absY/gird);
                   om.style.left=absX;
                   om.style.top=absY;
                   newX1=absX;newY1=absY;
                   //document.getElementById(widget_id).parentNode=n; // In my wild dreams I would do this, but it's a bit too rough for browsers
                   //so do the same in a polite & decent way :
    
                   var newom = om.cloneNode(true);
                   om.parentNode.removeChild(om);
                   n.appendChild(newom);
                   if(n.id!='morf') updpar="parent_id='"+n.id.substr(4)+"', ";
                   else updpar="parent_id=NULL, ";
             	 }
             	 showprops(newX1,newY1,widget_id); 
             }
           }
           else
           { updpar='';
             if(n!=document.getElementById(widget_id).parentNode)
             { //alert('You have dropped the widget on a new container('+n.id+' instead of '+document.getElementById(widget_id).parentNode.id+').\nYou can change this in the widget properties\n');
               var om = document.getElementById(widget_id);
               var absX=e.clientX+mouse2corner_x;
               var absY=e.clientY+mouse2corner_y;
               //alert('original xy:'+absX+','+absY+' mouse='+e.clientX+','+e.clientY+' delta='+mouse2corner_x+','+mouse2corner_y);
               var pn=n;
               while(pn.id!='morf')
               {
               	 //alert('xy:'+absX+','+absY+' parentXY:'+parseInt(pn.style.left,10)+','+parseInt(pn.style.top,10)+'('+pn.id+')');
               	 absX-=parseInt(pn.style.left,10);
               	 absY-=parseInt(pn.style.top,10);  
               	 pn=pn.parentNode;             	 
               }
               absX=gird*Math.round(absX/gird);
               absY=gird*Math.round(absY/gird);
               om.style.left=absX;
               om.style.top=absY;
               newX1=absX;newY1=absY;
               //document.getElementById(widget_id).parentNode=n; // In my wild dreams I would do this, but it's a bit too rough for browsers
               //so do the same in a polite & decent way :

               var newom = om.cloneNode(true);
               om.parentNode.removeChild(om);
               n.appendChild(newom);
               if(n.id!='morf') updpar="parent_id='"+n.id.substr(4)+"', ";
               else updpar="parent_id=NULL, ";
             }

             query="UPDATE widgets SET "+updpar+"x="+newX1+",y="+newY1+" WHERE widget_id="+widget_id.substr(4);
             do_query(query,'');
           }
        }
	// Releases the onmousemove event.
        window.onmousemove=null;
        window.onmouseup=null;
}


//----------------------------------------------------------------------------
// convert decimal color triplet to hex triplet
function tohex(x)
{
  x=x.substr(4,x.length-5);
  x=x.replace(/ /g,'');
  cols=x.split(',');
  cols[0]=1*cols[0];
  cols[1]=1*cols[1];
  cols[2]=1*cols[2];
  cols[0]=cols[0].toString(16); if(cols[0].length==1) { cols[0]='0'+cols[0]; }
  cols[1]=cols[1].toString(16); if(cols[1].length==1) { cols[1]='0'+cols[1]; }
  cols[2]=cols[2].toString(16); if(cols[2].length==1) { cols[2]='0'+cols[2]; }
  x=(cols[0].toString(16)+cols[1].toString(16)+cols[2].toString(16));
  x=x.toUpperCase();
  return(x);
}

//----------------------------------------------------------------------------
// Called when ending properties edition
function endprop(bol)
{
    document.getElementById('desiprop').style.left='-400px';
    document.getElementById('desiprop').style.top='0px';
    current_win='designer'; 	

    if(bol==1)
    {
       query='';
       h=document.propmorf.h.value;
       if(h!='')
       {
        document.getElementById(widget_id).style.height=h+'px';
        query+="height='"+h+"'";
       }
       else 
       { query+="height=NULL";
       	document.getElementById(widget_id).style.height='';
       }
       
       w=document.propmorf.w.value;
       if(w!='')
       {
        document.getElementById(widget_id).style.width=w+'px';
        query+=",width='"+w+"'";
       }
       else 
       { query+=",width=NULL";
       	 document.getElementById(widget_id).style.width='';
       }
       
       c=document.propmorf.color.value;
       if(c!='') query+=",widget_color='"+c+"'";
       else query+=",widget_color=NULL";
       if((c!='transparent')&&(c!='inherit')) { c='#'+c; }
       document.getElementById(widget_id).style.backgroundColor=c;
   
       c=document.propmorf.txtcolor.value;
       if(c!='') query+=",text_color='"+c+"'";
       else query+=",text_color=NULL";
       if((c!='transparent')&&(c!='inherit')) { c='#'+c; }
       document.getElementById(widget_id).style.color=c;
   
       h=document.propmorf.txtsize.options[document.propmorf.txtsize.selectedIndex].value;
       document.getElementById(widget_id).style.fontSize=h+'px';
       if(h!='') query+=",text_size='"+h+"'";
       else query+=",text_size=NULL";
   
       h=document.propmorf.bordertype.options[document.propmorf.bordertype.selectedIndex].value;
       document.getElementById(widget_id).style.borderStyle=h;
       if(h!='') query+=",border_type='"+h+"'";
       else query+=",border_type=NULL";
   
       h=document.propmorf.bsl.value;
       document.getElementById(widget_id).style.borderLeftWidth=h+'px';
       if(h!='') query+=",border_left='"+h+"'";
       else query+=",border_left=NULL";
   
       h=document.propmorf.bsr.value;
       document.getElementById(widget_id).style.borderRightWidth=h+'px';
       if(h!='') query+=",border_right='"+h+"'";
       else query+=",border_right=NULL";
   
       h=document.propmorf.bst.value;
       document.getElementById(widget_id).style.borderTopWidth=h+'px';
       if(h!='') query+=",border_top='"+h+"'";
       else query+=",border_top=NULL";
   
       h=document.propmorf.bsb.value;
       document.getElementById(widget_id).style.borderBottomWidth=h+'px';
       if(h!='') query+=",border_bottom='"+h+"'";
       else query+=",border_bottom=NULL";
   
       c=document.propmorf.bordcolor.value;
       if(c!='') query+=",border_color='"+c+"'";
       else query+=",border_color=NULL";
       if((c!='transparent')&&(c!='inherit')) { c='#'+c; }
       document.getElementById(widget_id).style.borderColor=c;
   
       h=document.propmorf.txtalign.options[document.propmorf.txtalign.selectedIndex].value;
       document.getElementById(widget_id).style.textAlign=h;
       if(h!='') query+=",text_align='"+h+"'";
       else query+=",text_align=NULL";
   
       h=document.propmorf.txtdecoration.options[document.propmorf.txtdecoration.selectedIndex].value;
       document.getElementById(widget_id).style.textDecoration=h;
       if(h!='') query+=",text_deco='"+h+"'";
       else query+=",text_deco=NULL";


       h=document.propmorf.txtstyle.options[document.propmorf.txtstyle.selectedIndex].value;

       if(h=='inherit') { document.getElementById(widget_id).style.fontStyle=h; document.getElementById(widget_id).style.fontWeight=h; }
       else 
       {
        if(h.indexOf('I')!=-1) document.getElementById(widget_id).style.fontStyle='italic';
        else  document.getElementById(widget_id).style.fontStyle='normal';
        if(h.indexOf('B')!=-1) document.getElementById(widget_id).style.fontWeight='bold';
        else  document.getElementById(widget_id).style.fontWeight='normal';
       }
       query+=",text_style='"+h+"'";
   
       if(document.getElementById(widget_id).nodeName=="IMG")
       { h=document.propmorf.bgimage.value;
         query+=",image_url='"+h+"'"; 
         if((h!="")&&(h.substr(0,1)!="/")&&(h.substr(0,7)!="http://")) h="../"+h;
         document.getElementById(widget_id).src=h;
       }
       else
       { h=document.propmorf.bgimage.value;
         query+=",image_url='"+h+"'";  
         if((h!="")&&(h.substr(0,1)!="/")&&(h.substr(0,7)!="http://")) h="../"+h;
         document.getElementById(widget_id).style.backgroundImage='url('+h+')';

         h=document.propmorf.bgrepeat.options[document.propmorf.bgrepeat.selectedIndex].value;
         document.getElementById(widget_id).style.backgroundRepeat=h;
         query+=",image_repeat='"+h+"'";       
       }

       x=document.propmorf.x.value;
       document.getElementById(widget_id).style.left=x+'px';
       
       y=document.propmorf.y.value;
       document.getElementById(widget_id).style.top=y+'px';

       h=document.propmorf.hidden.checked;
       if(h)
       { 
        document.getElementById(widget_id).style.top='-10000px';
        document.getElementById(widget_id).style.left=-'10000px';
        query+=",hidden='Y'";
        //add in selector
        document.desimorf.showwhat.options[document.desimorf.showwhat.options.length]=new Option(widget_id,widget_id.substr(4));
        document.desimorf.showwhat.selectedIndex=0;
       }
       else
       {
        query+=",hidden='N'";
        //remove from selector
        for(i=0;i<document.desimorf.showwhat.options.length;i++) 
        { if(document.desimorf.showwhat.options[i].value==widget_id) document.desimorf.showwhat.options[i]=null; }
        document.desimorf.showwhat.selectedIndex=0;
       }


       h=document.propmorf.parent.options[document.propmorf.parent.selectedIndex].value; 
       updpar='';
       if((h!=document.getElementById(widget_id).parentNode.id) || (adding))
       { //parent has changed !
         n=document.getElementById(h);
         var om = document.getElementById(widget_id);
         var absX=parseInt(x,10);
         var absY=parseInt(y,10);
         var pn=om.parentNode; 
         while(pn.id!='morf')
         {       
         	 absX+=parseInt(pn.style.left,10);
         	 absY+=parseInt(pn.style.top,10);  
         	 pn=pn.parentNode;             	 
         }
         var pn=n; 
         while(pn.id!='morf')
         {
         	 absX-=parseInt(pn.style.left,10);
         	 absY-=parseInt(pn.style.top,10);  
         	 pn=pn.parentNode;             	 
         }
         om.style.left=absX;
         om.style.top=absY;
	 x=absX;y=absY;
         //document.getElementById(widget_id).parentNode=n; // In my wild dreams I would do this, but it's a bit too rough for browsers
         //so do the same in a polite & decent way :
         var newom = om.cloneNode(true);
         om.parentNode.removeChild(om);
         n.appendChild(newom);
         if(n.id!='morf') updpar=",parent_id='"+n.id.substr(4)+"'";
         else updpar=",parent_id=NULL ";
         query+=updpar;       

       }

       query+=",x='"+x+"'";
       query+=",y='"+y+"'";
   
       if(!adding)
       { query="UPDATE widgets SET "+query+" WHERE widget_id="+widget_id.substr(4);
         do_query(query,'');   
       }
       else
       {   witype=document.getElementById(widget_id).nodeName.toLowerCase();
           if(witype=='input') witype=document.getElementById(widget_id).type;
           if(witype=='img') witype='image';
           query+=", widget_type='"+witype+"',window_id='"+urlParams["window_id"]+"'";
           query="INSERT INTO widgets SET "+query ;
           do_query(query,"update_new_id('"+widget_id+"')");
       }
    } 	
    window.onmousedown=mouseclick;
    widget_id='';

}

function update_new_id(tmp_id)
{
    document.getElementById(tmp_id).defaultValue='wid_'+inserted_id;
    document.getElementById(tmp_id).id='wid_'+inserted_id;	
}

function over_desimain(x,y)
{
  dmx=document.getElementById('desimain').style.left.substr(0,document.getElementById('desimain').style.left.length-2);
  dmy=document.getElementById('desimain').style.top.substr(0,document.getElementById('desimain').style.top.length-2);
  dmx2=1*dmx+1*document.getElementById('desimain').style.width.substr(0,document.getElementById('desimain').style.width.length-2);
  dmy2=1*dmy+1*document.getElementById('desimain').style.height.substr(0,document.getElementById('desimain').style.height.length-2);
  return((x>=dmx)&&(x<=dmx2)&&(y>=dmy)&&(y<=dmy2));	
}

function over_what(x,y)
{
  over_nodes=new Array(); over_nodes_depths=new Array();
  ovwt_x=x;ovwt_y=y;
  ovwt(document.morf,0,0,0);
}

function ovwt(n,depth,offsetx,offsety) {  
    if (n.nodeType == 1 /*Node.ELEMENT_NODE*/)  // Check if n is an Element
    {  var x1=n.style.left; var y1=n.style.top; 
    //alert(n.id+'='+x1+'='+y1);
       if(n.id.length>0)
       {  
          var dmx=1*(x1.substr(0,x1.length-2))+offsetx;
          var dmy=1*(y1.substr(0,y1.length-2))+offsety;
           
          if(n.nodeName=='IMG') { dmw=parseInt(n.naturalWidth,10); dmh=parseInt(n.naturalHeight,10); }
          else 
          { var w1=n.style.width; var dmw=1*(w1.substr(0,w1.length-2));
            var h1=n.style.height; var dmh=1*(h1.substr(0,h1.length-2));
          }
          var dmx2=dmx+dmw;
          var dmy2=dmy+dmh;
          if((ovwt_x>=dmx)&&(ovwt_x<=dmx2)&&(ovwt_y>=dmy)&&(ovwt_y<=dmy2)) 
          { over_nodes.push(n);over_nodes_depths.push(depth); }
       }
    }
    var children = n.childNodes;                // Now get all children of n
    for(var i=0; i < children.length; i++) {    // Loop through the children
        ovwt(children[i],depth+1,dmx,dmy);      // Recurse on each one
    }
}

function mouseclick(e)
{
 if(!response_arrived) { return; }
 if(current_win!='designer') { return; }
 if((e.target.getAttribute("ID")=='debugit')||(e.target.getAttribute("ID")=='maggird')) { return; }
 e.preventDefault();
  
 // Stores the current mouse position for further use.
 window.lastX=parseInt(e.clientX,10);
 window.lastY=parseInt(e.clientY,10);
 

 if(e.which==1) //left button
 {
    widget_id=e.target.getAttribute("ID");
    if(widget_id) //we're on a widget 
    {  var widget=e.target;
       resizing='';

       if((widget_id!='desitop') && (widget_id!='desimain')&&(widget_id.substr(0,4)!="add_"))
       {
         // get the distance between mouse position and widget corner
         // more complex than it seems because mouse position is absolute
         // while widget position is relative to parent(s),
         // so we need to klimb the DOM tree back to top (morf), adding parents positions
         var absX=parseInt(widget.style.left,10);
         var absY=parseInt(widget.style.top,10); 
         var pn=widget.parentNode;
         while(pn.id!='morf')
         {
         	 absX+=parseInt(pn.style.left,10);
         	 absY+=parseInt(pn.style.top,10);  
         	 pn=pn.parentNode;             	 
         }    	
         mouse2corner_x=absX-window.lastX;
         mouse2corner_y=absY-window.lastY;

       //Check if in resize zone of widget

       x2=absX+parseInt(widget.style.width,10); y2=absY+parseInt(widget.style.height,10); 
       if((e.clientY+document.body.scrollTop>y2-6)) resizing='s';
       if((e.clientX+document.body.scrollLeft>x2-6)) resizing='e';
       if((e.clientX+document.body.scrollLeft>x2-6)&&(e.clientY+document.body.scrollTop>y2-6)) resizing='se';

       }


       if(widget_id.substr(0,4)=="add_") //////////////// ADDING
       { 
         document.desimorf.ax[0].checked=true; document.desimorf.ax[1].checked=false; document.desimorf.ax[2].checked=false;document.desimorf.ax[3].checked=false;
         var newnode = document.getElementById(widget_id).cloneNode(true);
         newnode.id="new1";
         document.morf.appendChild(newnode);
         widget_id="new1"; widget=document.getElementById('new1');
         w=parseInt(widget.style.width,10);
         h=parseInt(widget.style.height,10);
         if((widget.type!='radio')&&(widget.type!='checkbox')) w=Math.floor(w/2); 
         widget.style.top=window.lastY-Math.floor(h/2)+document.body.scrollTop; 
         widget.style.left=window.lastX-w+document.body.scrollLeft;
         widget.style.color="#000000"; 
         widget.style.cursor='pointer';
	 widget.onmouseover=chkresizeon;
	 widget.onmouseout=chkresizeoff;
         if(widget.type=='button') widget.style.backgroundColor='#CCCCCC'; 
         else if((widget.type=='radio')||(widget.type=='checkbox')) widget.style.backgroundColor='inherit'; 
         else widget.style.backgroundColor='#FFFFFF'; 
         widget.style.zIndex='5000';
         adding=true;
       }
       else
       { adding=false; }  

       if(resizing.length>0)                          ////////////////////////////////////// RESIZING
       {
           if((widget_id=='desitop')||(widget_id=='desimain')) return;
           widget.onmouseover=null;
           widget.onmouseout=null;
	   window.onmousedown=null;
           window.onmousemove=doResize;
           window.onmouseup=endResize;
       }
       else if((document.desimorf.ax[0].checked) || (widget_id=='desitop')) //////////////// MOVING
       {
           window.onmousemove=doDrag;
           window.onmouseup=endDrag;
           
           if(widget_id=='desitop')
           {
             widget_id='desimain';	
           }
                  else
           {
             /*dispproperties(widget_id);*/
             //savezindex=document.getElementById(widget_id).style.zIndex;
                   
             document.getElementById(widget_id).style.zIndex="5000";
           }
        }
        else if((!over_desimain(e.clientX,e.clientY))&&(document.desimorf.ax[1].checked)) /////////////////////PROPERTIES
        {
           showprops(e.clientX,e.clientY,widget_id);
        }
        else if((!over_desimain(e.clientX,e.clientY))&&(document.desimorf.ax[2].checked)) //////////////////////TEXT/LABEL
        {
           showtext(e.clientX,e.clientY,widget_id);
        }
        else if((!over_desimain(e.clientX,e.clientY))&&(document.desimorf.ax[4].checked)) //////////////////////JS ACTION
        {
           showaction(widget_id);
        }
        else if((!over_desimain(e.clientX,e.clientY))&&(document.desimorf.ax[3].checked)) //////////////////////DELETE
        {
        	//document.desimorf.ax[2].checked=false; // wanna reset to move after delete ?
                //document.desimorf.ax[1].checked=true;
        	if(!confirm('Are you sure you want to delete\n'+widget_id+ '?')) return;
                query='delete from widgets where widget_id='+widget_id.substr(4);
                do_query(query,'');
        	objecttodestroy = document.getElementById(widget_id);
                document.morf.removeChild(objecttodestroy);

        }
    }
    else //we're not on a widget => make a marquee
    {
    	//marq_start_x=e.clientX;
    	//marq_start_y=e.clientY;
    	//document.getElementById('marquee').style.left=marq_start_x+"px";
    	//document.getElementById('marquee').style.top=marq_start_y+"px";
    	//// Register doDrag event handler to receive generic onmousemove events. 
        //window.onmousemove=doMarquee;
        // 
        //// Register endDrag event handler to receive generic onmouseup events. 
        //window.onmouseup=endMarquee;
    }
 }
}	

function showaction(widget_id)
{
	   window.onmousedown=null;
	   current_win='actionprop'; 
           document.getElementById('desiaction').style.left='10px';
           document.getElementById('desiaction').style.zIndex=document.getElementById('desimain').style.zIndex+100;
           document.getElementById('actiontitle').lastChild.nodeValue=' Actions for '+widget_id;
           document.actionmorf.actevent.selectedIndex=0;
           document.getElementById('action').value="";
           query="SELECT type,function FROM actions WHERE widget_id='"+widget_id.substr(4)+"' ";
           do_query(query,'fill_actions();'); 
}

function fill_actions()
{
 actionstab = new Array();
 for(i=0;i<nbresults;i++)
 { 
   actionstab[tab[i][0]]=unescape(tab[i][1]);
 }
 previdx=0;
}

function selectaction(idx)
{
 if(previdx!=0)
 {
   eve=document.actionmorf.actevent.options[previdx].value;
   actionstab[eve]=document.getElementById('action').value;    	
 }
 eve=document.actionmorf.actevent.options[idx].value;
 if(actionstab[eve]) document.getElementById('action').value=actionstab[eve];
 else document.getElementById('action').value='';
 previdx=idx;
}

function endaction(bol)
{
 if(bol==0)
 {
 }
 else
 { selectaction(document.actionmorf.actevent.selectedIndex);
 	
   events=document.actionmorf.actevent.options;
   for(i=0;i<events.length;i++)
   {
     action=actionstab[events[i].value];
     if(action)
     {// re=/'/g;
      // action=action.replace(re,"\\\\'");
      action=escape(action);
       re=/\+/g; // the wonderfull escape function *JUST* forget about the + sign... so do it ourselves
       action=action.replace(re,"%2B");
      
       query="REPLACE INTO actions set widget_id='"+widget_id.substr(4)+"',type='"+events[i].value+"', function='"+action+"'";
       query=escape(query);
       re=/\+/g; // the wonderfull escape function *JUST* forget about the + sign... so do it ourselves
       query=query.replace(re,"%2B");

       do_query(query,'');
     }
   }

 }
 document.getElementById('desiaction').style.left=-1000;
 current_win='designer'; 
 window.onmousedown=mouseclick;
}

function showtext(ex,ey,widget_id)
{
	   window.onmousedown=null;
	   current_win='textprop'; 
           x=ex+50; 

           wi=1*(document.getElementById('desitxtprop').style.width.substr(0,document.getElementById('desitxtprop').style.width.length-2));
           if(x+wi>document.body.clientWidth) {x=ex-50-wi;}
           document.getElementById('desitxtprop').style.left=x+'px';
           
           hi=1*(document.getElementById('desitxtprop').style.height.substr(0,document.getElementById('desitxtprop').style.height.length-2));
           y=Math.floor(ey-(hi/2));
           if(y<10) {y=10; }
           if(y+hi+10>document.body.clientHeight) { y=document.body.clientHeight-hi-10; }
           document.getElementById('desitxtprop').style.top=y+'px';
           document.getElementById('desitxtprop').style.zIndex=document.getElementById('desimain').style.zIndex+100;
           
           document.getElementById('proptxttitle').lastChild.nodeValue=' Label(s) for '+widget_id;
           query="SELECT b.name,a.label,b.lg FROM getxt as a left join languages as b ON a.lg=b.lg WHERE a.id='"+widget_id+"' ORDER BY b.name";
           do_query(query,'fill_label_tbl();'); ///"add_tbl_lines('txtlabeltable',tab,'header');"
           query="SELECT lg,name FROM languages ORDER BY name";
           do_query(query,"fill_selector('labellg_new');"); ///"add_tbl_lines('txtlabeltable',tab,'header');"
}

function endtxtprop(bol)
{
 if(bol==0)
 {
    k=label_tbl.length;
    while(k-->0) del_tbl_line('txtlabeltable',k+1);
 }
 else
 {
  query="DELETE FROM getxt WHERE id='"+widget_id+"'";
  do_query(query,'');
  for(i=0;i<label_tbl.length;i++)
  {
   query="INSERT INTO getxt set id='"+widget_id+"',lg='"+label_tbl[i][0]+"', label='"+label_tbl[i][1]+"'";
   query=escape(query);
   re=/\+/g; // the wonderfull escape function *JUST* forget about the + sign... so do it ourselves
   query=query.replace(re,"%2B");
   
   do_query(query,'');

   if(label_tbl[i][0]==urlParams['lg']) 
   { var wi=document.getElementById(widget_id);
     if(wi.nodeName.toLowerCase()=='div') 
     {  if(wi.innerHTML.indexOf('<')>-1) {  wi.innerHTML=label_tbl[i][1]+wi.innerHTML.substr(wi.innerHTML.indexOf('<')); }
        else wi.textContent=label_tbl[i][1]; 
     }
     if(wi.nodeName.toLowerCase()=='textarea') wi.textContent=label_tbl[i][1]; 
     if((wi.nodeName.toLowerCase()=='input')&&((wi.type.toLowerCase()=='button')||(wi.type.toLowerCase()=='text'))) wi.value=label_tbl[i][1]; 
     if(wi.nodeName.toLowerCase()=='image') wi.alt=label_tbl[i][1]; 
   }
  }
//  if(curlgexists==false)
//  {
//     var wi=document.getElementById(widget_id);
//     curlgexists=true;
//     if(wi.nodeName.toLowerCase()=='div') 
//     {  if(wi.innerHTML.indexOf('<')>-1) {  wi.innerHTML=wi.innerHTML.substr(wi.innerHTML.indexOf('<')); }
//        else wi.textContent=''; 
//     }
//     if(wi.nodeName.toLowerCase()=='textarea') wi.textContent=''; 
//     if((wi.nodeName.toLowerCase()=='input')&&((wi.type.toLowerCase()=='button')||(wi.type.toLowerCase()=='text'))) wi.value=''; 
//     if(wi.nodeName.toLowerCase()=='image') wi.alt=''; 
//  }
 }
 document.getElementById('desitxtprop').style.left=-300;
 current_win='designer'; 
 window.onmousedown=mouseclick;
}

function addlabel()
{
  if(document.proptxtmorf.label_new.value=='') { return; }
  var isel=document.proptxtmorf.lg_new.selectedIndex;
  var lg=document.proptxtmorf.lg_new.options[isel].value;
  i=0; while((i<document.proptxtmorf.lg_new.options.length)&&(document.proptxtmorf.lg_new.options[i].value!=lg)) i++;
  k=0; while((k<languages_tab.length)&&(languages_tab[k][0]!=lg)) {  k++; }
  var lgname=languages_tab[k][1];
  if(urlParams['lg']==lg)
        var line=new Array(lgname,'<input type="text" size="20" class="propfield" style="background-color:DDFFDD;" name="label_'+lg+'" value="'+document.proptxtmorf.label_new.value+'" onBlur="updtlabel(this);>','<img src="/jsdesigner/images/btn_trash.gif" onclick="dellabel('+label_tbl.length+');"/>');	 
  else
        var line=new Array(lgname,'<input type="text" size="20" class="propfield" name="label_'+lg+'" value="'+document.proptxtmorf.label_new.value+'" onBlur="updtlabel(this);>','<img src="/jsdesigner/images/btn_trash.gif" onclick="dellabel('+label_tbl.length+');"/>');	 
  var ta=document.getElementById('txtlabeltable');
  label_tbl[label_tbl.length]=new Array(lg,document.proptxtmorf.label_new.value);

  add_tbl_lines('txtlabeltable',line,label_tbl.length);
  document.proptxtmorf.label_new.value='';
  document.proptxtmorf.lg_new.options[isel]=null;
  if(document.proptxtmorf.lg_new.options.length==0) {  del_tbl_line('txtlabeltable',label_tbl.length+1); }
  document.proptxtmorf.label_new.focus();
}

function updtlabel(n)
{
  var lg=n.name.substr(6);
  k=0; while((k<label_tbl.length)&&(label_tbl[k][0]!=lg)) { k++; }
  label_tbl[k][1]=n.value;
}

function dellabel(i)
{
  del_tbl_line('txtlabeltable',i+1);
  k=0; while((k<languages_tab.length)&&(languages_tab[k][0]!=label_tbl[i][0])) {  k++; }
  
  if(document.proptxtmorf.lg_new.options.length==0)
  {
	var newfield = new Array('<select id="labellg_new" class="propfield" name="lg_new"></select>','<input type="text" name="label_new" size="20" class="propfield" onKeyPress="if(event.keyCode==13) addlabel();" onBlur="addlabel();">','&nbsp;');
	add_tbl_lines('txtlabeltable',newfield,'all');
  }
  document.proptxtmorf.lg_new.options[document.proptxtmorf.lg_new.options.length]=new Option(languages_tab[k][1],languages_tab[k][0]);  
  for(j=i;j<label_tbl.length-1;j++) label_tbl[j]=label_tbl[j+1];
  label_tbl.pop();
}

function fill_label_tbl()
{
        var smalltab= new Array();
        label_tbl= new Array();
        keep='header';
        if(nbresults>0)
        {
	 for(i=0;i<tab.length;i++) 
	 { if(urlParams['lg']==tab[i][2])
               smalltab[i] = new Array(tab[i][0],'<input type="text" size="20" class="propfield" style="background-color:DDFFDD;" name="label_'+tab[i][2]+'" value="'+unescape(tab[i][1])+'" onBlur="updtlabel(this);">','<img src="/jsdesigner/images/btn_trash.gif" onclick="dellabel('+i+');"/>');
           else
               smalltab[i] = new Array(tab[i][0],'<input type="text" size="20" class="propfield" name="label_'+tab[i][2]+'" value="'+unescape(tab[i][1])+'" onBlur="updtlabel(this);">','<img src="/jsdesigner/images/btn_trash.gif" onclick="dellabel('+i+');"/>');
           label_tbl[i]=new Array(tab[i][2],tab[i][1]);
	 }
 	 add_tbl_lines('txtlabeltable',smalltab,'header');
 	 keep='all';
 	} 
 	
	var newfield = new Array('<select id="labellg_new" class="propfield" name="lg_new"></select>','<input type="text" name="label_new" size="20" class="propfield" onKeyPress="if(event.keyCode==13) addlabel();" onBlur="addlabel();">','&nbsp;');
	add_tbl_lines('txtlabeltable',newfield,keep);

}
 
function fill_selector(id)
{
        var n=document.getElementById(id);
        languages_tab=tab; j=0;
	for(i=0;i<languages_tab.length;i++) 
	{ 
          k=0; while((k<label_tbl.length)&&(label_tbl[k][0]!=languages_tab[i][0])) { k++; }
          if(k==label_tbl.length) n.options[j++]=new Option(languages_tab[i][1],languages_tab[i][0]); 
	}
        if(j==0) 
        {   document.proptxtmorf.lg_new.options[0]=null; // so that the options object exists for the dellabel proc 
            del_tbl_line('txtlabeltable',label_tbl.length+1); 
        }

}
function showprops(ex,ey,widget_id)
{
	   window.onmousedown=null;
	   
           x=ex+50; 

           wi=parseInt(document.getElementById('desiprop').style.width,10);
           if(x+wi>document.body.clientWidth) {x=ex-50-wi;}
           document.getElementById('desiprop').style.left=x+'px';
           
           hi=parseInt(document.getElementById('desiprop').style.height,10);
           y=Math.floor(ey-(hi/2));
           if(y<10) {y=10; }
           if(y+hi+10>document.body.clientHeight) { y=document.body.clientHeight-hi-10; }
           document.getElementById('desiprop').style.top=y+'px';
           document.getElementById('desiprop').style.zIndex=document.getElementById('desimain').style.zIndex+100;
           
           document.getElementById('proptitle').lastChild.nodeValue=' Properties of '+widget_id;
           
           document.propmorf.hidden.checked=false;
           
           x=parseInt(document.getElementById(widget_id).style.left,10);
           document.propmorf.x.value=x;
           y=parseInt(document.getElementById(widget_id).style.top,10);
           document.propmorf.y.value=y;
           h=parseInt(document.getElementById(widget_id).style.height,10);
           if(!h) h='';
           document.propmorf.h.value=h;
           w=parseInt(document.getElementById(widget_id).style.width,10);
           if(!h) h='';
           document.propmorf.w.value=w;
           c=document.getElementById(widget_id).style.backgroundColor; 
           if((c!='transparent')&&(c!='inherit')&&(c!='')) c=tohex(c);
           document.propmorf.color.value=c;
           
           c=document.getElementById(widget_id).style.color;
           if((c)&&(c!='inherit')&&(c!='')) c=tohex(c);
           document.propmorf.txtcolor.value=c;
           h=document.getElementById(widget_id).style.fontSize;
           h=h.substr(0,h.indexOf('px'));
           for(i=0;i<document.propmorf.txtsize.length;i++)
           {
            if(document.propmorf.txtsize.options[i].value==h) { document.propmorf.txtsize.options[i].selected=true; }
           }
           h=document.getElementById(widget_id).style.borderStyle;
           h=h.substr(0,h.indexOf(' '));
           for(i=0;i<document.propmorf.bordertype.length;i++)
           {
            if(document.propmorf.bordertype.options[i].value==h) { document.propmorf.bordertype.options[i].selected=true; }
           }
           bsl=parseInt(document.getElementById(widget_id).style.borderLeftWidth,10);
           if((bsl!=0)&&(!bsl)) bsl='';
           document.propmorf.bsl.value=bsl;
           bsr=parseInt(document.getElementById(widget_id).style.borderRightWidth,10);
           if((bsr!=0)&&(!bsr)) bsr='';
           document.propmorf.bsr.value=bsr;
           bst=parseInt(document.getElementById(widget_id).style.borderTopWidth,10);
           if((bst!=0)&&(!bst)) bst='';
           document.propmorf.bst.value=bst;
           bsb=parseInt(document.getElementById(widget_id).style.borderBottomWidth,10);
           if((bsb!=0)&&(!bsb)) bsb='';
           document.propmorf.bsb.value=bsb;
           c=document.getElementById(widget_id).style.borderColor;
           c=c.substr(0,c.indexOf(' rgb('));
           if((c!='transparent')&&(c!='inherit')&&(c!='')) c=tohex(c);
           document.propmorf.bordcolor.value=c;       

           h=document.getElementById(widget_id).style.textAlign;
           for(i=0;i<document.propmorf.txtalign.length;i++)
           {
            if(document.propmorf.txtalign.options[i].value==h) { document.propmorf.txtalign.options[i].selected=true; }
           }

           h=document.getElementById(widget_id).style.textDecoration;
           for(i=0;i<document.propmorf.txtdecoration.length;i++)
           {
            if(document.propmorf.txtdecoration.options[i].value==h) { document.propmorf.txtdecoration.options[i].selected=true; }
           }

           h1=document.getElementById(widget_id).style.fontWeight;
           h2=document.getElementById(widget_id).style.fontStyle;
           if((h1=='inherit')&&(h2=='inherit')) h='inherit';
           else 
           { if(h1=='bold') h='B'; else h='N';
             if(h2=='italic') h+='I'; 
             if(h=='') h='N';
           }
           for(i=0;i<document.propmorf.txtstyle.length;i++)
           {
            if(document.propmorf.txtstyle.options[i].value==h) { document.propmorf.txtstyle.options[i].selected=true; }
           }

           if(document.getElementById(widget_id).nodeName=="IMG")
           {  document.propmorf.bgimage.value=document.getElementById(widget_id).src;
              document.getElementById('bgimagerepeat').style.left='-300px';
           }
           else
           { h=document.getElementById(widget_id).style.backgroundImage;
             if(h.length>5)  h=h.substring(4,h.length-1); //kick the url()
             if(h.substring(0,3)=='../') h=h.substr(3);
             document.propmorf.bgimage.value=h;
             document.propmorf.bgrepeat.value=document.getElementById(widget_id).style.backgroundRepeat;
             document.getElementById('bgimagerepeat').style.left='0px';
           }

           fill_parents();
           h=document.getElementById(widget_id).parentNode.id;
           for(i=0;i<document.propmorf.parent.length;i++)
           {
            if(document.propmorf.parent.options[i].value==h) { document.propmorf.parent.options[i].selected=true; }
           }

           current_win='properties';
	
}

function fill_parents()
{
  parenttab = new Array();
  surf(document.morf); 
  nbopt=document.getElementById('parentid').options.length;
  for (var i=1; i<nbopt;i++)  document.getElementById('parentid').options[1]=null; 

  for (var i=0; i<parenttab.length; i++) { document.getElementById('parentid').options[document.getElementById('parentid').options.length]=new Option(parenttab[i],parenttab[i]); }

}

function surf(n) {  
    if (n.nodeType == 1 /*Node.ELEMENT_NODE*/)  // Check if n is an Element
    { 
       if((n.id.length>0)&&(n.nodeName=='DIV')) { parenttab.push(n.id);  }
    }
    var children = n.childNodes;                // Now get all children of n
    for(var i=0; i < children.length; i++) {    // Loop through the children
        surf(children[i]);      // Recurse on each one
    }
}

function chkresize(e)
{
 n=e.target; 
 var x1=parseInt(n.style.left,10);
 var y1=parseInt(n.style.top,10); 
 var pn=n.parentNode;
 while(pn.id!='morf')
 {
 	 x1+=parseInt(pn.style.left,10);
 	 y1+=parseInt(pn.style.top,10);  
 	 pn=pn.parentNode;             	 
 }    	

 x2=x1+parseInt(n.style.width,10); y2=y1+parseInt(n.style.height,10); 
 if((e.clientX+document.body.scrollLeft>x2-detect_resize_width)&&(e.clientY+document.body.scrollTop>y2-detect_resize_width)) { e.target.style.cursor='se-resize'; return; }
 if((e.clientY+document.body.scrollTop>y2-detect_resize_width)) { e.target.style.cursor='s-resize'; return; }
 if((e.clientX+document.body.scrollLeft>x2-detect_resize_width)) { e.target.style.cursor='e-resize'; return; }
 window.status=n.id+" X:"+e.clientX+" Y:"+e.clientY;
 e.target.style.cursor='pointer';
}

function doMarquee(e)
{
	// Calculates the difference between the last mouse position
	// and the current position. 
	//
        //var difX=e.clientX-window.lastX;
        //var difY=e.clientY-window.lastY;

	// Stores the current mouse position.
	//
        //window.lastX=e.clientX;
        //window.lastY=e.clientY;
     	var w=e.clientX-marq_start_x;
     	if(w<0)
     	{ marq_start_x+=w;
     	  document.getElementById('marquee').style.left=marq_start_x+"px";
     	  w=-w;
        }
    	var h=e.clientY-marq_start_y;
    	if(h<0)
     	{ marq_start_y+=h;
     	  document.getElementById('marquee').style.top=marq_start_y+"px";
     	  h=-h;
        }
    	document.getElementById('marquee').style.width=w+"px";
    	document.getElementById('marquee').style.height=h+"px";       
        
}	

function endMarquee(e)
{
         window.onmousemove=null;
         window.onmouseup=null;	
}

function showhidden(selidx)
{
 wid_id=document.desimorf.showwhat.options[selidx].value;
 query="SELECT x,y FROM widgets WHERE widget_id="+wid_id;
 do_query(query,"showhidden2('wid_"+wid_id+"');");
 query="UPDATE widgets SET hidden='N' WHERE widget_id="+wid_id;
 do_query(query,'');
 document.desimorf.showwhat.selectedIindex=0;
 document.desimorf.showwhat.options[selidx]=null;
}

function showhidden2(wid_id)
{
 document.getElementById(wid_id).style.left=tab[0][0]+'px';	
 document.getElementById(wid_id).style.top=tab[0][1]+'px';
 
}
