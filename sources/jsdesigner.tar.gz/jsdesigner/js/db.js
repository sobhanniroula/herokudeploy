   db_queue= new Array(); 
   query_queue= new Array(); 
   ax_queue= new Array();

   function do_query(query,ax,db)
   {
    if(!db) db='';
    if(ax_queue.length>0) { query_queue.push(query); db_queue.push(db);}
    else { exec_query(query,db);}
    ax_queue.push(ax);
   }


   function exec_query(query,db)
   {    
   	if(query=='') { return; }
        
        newscrpt=document.createElement('SCRIPT');
        newscrpt.setAttribute('id','dbscript')
        newscrpt.setAttribute('language','javascript')

        var escquery=escape(query);
        re=/\+/g; // the wonderfull escape function *JUST* forget about the + sign... so do it ourselves
        escquery=escquery.replace(re,"%2B");

        if(db!='')
        { var escdb=escape(db);
          re=/\+/g; // the wonderfull escape function *JUST* forget about the + sign... so do it ourselves
          escdb=escdb.replace(re,"%2B");
          url='/jsdesigner/includes/query.js.php?rnd='+10000*Math.random()+'&query='+escquery+'&db='+escdb;
        }
        else url='/jsdesigner/includes/query.js.php?rnd='+10000*Math.random()+'&query='+escquery;
        if(document.getElementById('debugit')) document.getElementById('debugit').value=url;
        newscrpt.setAttribute('src',url)
        container=document.getElementById('dbscript_parent');

        response_arrived=false;
        container.replaceChild(newscrpt,document.getElementById('dbscript')); 
        document.body.style.cursor='wait';
        setTimeout('checkarrival();',10);
   }
   
   function checkarrival()
   {
     if(!response_arrived) setTimeout('checkarrival();',10);
     else 
     { if(query_debug!='') alert(query_debug);

       post_query_ax=ax_queue.shift();
            
       
       //Start next query in 50ms, time to finish first this proc
       if(query_queue.length>0) setTimeout('exec_query(query_queue.shift(),db_queue.shift());',50);
       

              
       document.body.style.cursor='default';
       if(query_err!='') alert('SQL ERROR:'+query_err);
       else eval(post_query_ax); 
     }
   }
