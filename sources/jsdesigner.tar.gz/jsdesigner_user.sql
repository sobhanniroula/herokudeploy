INSERT INTO `user` ( `Host` , `User` , `Password`) 
VALUES ('localhost', 'jsdesigner', PASSWORD( '1234' ));

INSERT INTO `db` ( `Host` , `Db` , `User` , `Select_priv` , `Insert_priv` , `Update_priv` , `Delete_priv` )
VALUES ('localhost', 'gui', 'jsdesigner', 'Y', 'Y', 'Y', 'Y');

