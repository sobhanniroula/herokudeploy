#
# JS Designer 1.0
# 
#
# Start by creating a database named "gui"
# Then feed the SQL below to create appropriate tables
#

# --------------------------------------------------------

#
# Table structure for table `actions`
#

CREATE TABLE `actions` (
  `widget_id` int(10) unsigned NOT NULL default '0',
  `type` varchar(100) NOT NULL default 'Click',
  `function` text NOT NULL,
  PRIMARY KEY  (`widget_id`,`type`)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table `getxt`
#

CREATE TABLE `getxt` (
  `id` varchar(20) NOT NULL default '',
  `lg` char(2) NOT NULL default '',
  `label` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`id`,`lg`)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table `languages`
#

CREATE TABLE `languages` (
  `lg` char(2) NOT NULL default '',
  `name` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`lg`)
) TYPE=MyISAM;

INSERT INTO `languages` VALUES ('en', 'English');
INSERT INTO `languages` VALUES ('fr', 'French');
# --------------------------------------------------------

#
# Table structure for table `select_source`
#

CREATE TABLE `select_source` (
  `widget_id` int(10) unsigned NOT NULL default '0',
  `table_name` varchar(255) NOT NULL default '',
  `val_col_name` varchar(255) NOT NULL default '',
  `label_col_name` varchar(255) NOT NULL default '',
  `where_clause` varchar(255) NOT NULL default '',
  `order_clause` varchar(255) NOT NULL default ''
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table `subwindows`
#

CREATE TABLE `subwindows` (
  `id` varchar(20) NOT NULL default '',
  `parent_id` varchar(20) NOT NULL default '',
  `base_widget_id` int(10) unsigned NOT NULL default '0',
  `x` int(11) NOT NULL default '0',
  `y` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table `widgets`
#

CREATE TABLE `widgets` (
  `widget_id` int(10) unsigned NOT NULL auto_increment,
  `parent_id` int(10) unsigned default NULL,
  `hidden` char(1) NOT NULL default '',
  `widget_type` varchar(20) NOT NULL default '',
  `window_id` varchar(20) NOT NULL default '',
  `class` varchar(255) default NULL,
  `x` int(11) NOT NULL default '0',
  `y` int(11) NOT NULL default '0',
  `height` int(11) default '0',
  `width` int(11) default '0',
  `text_size` int(11) default '0',
  `text_color` varchar(12) default NULL,
  `widget_color` varchar(12) default NULL,
  `border_type` varchar(6) default NULL,
  `border_left` int(11) default '0',
  `border_right` int(11) default '0',
  `border_top` int(11) default '0',
  `border_bottom` int(11) default '0',
  `border_color` varchar(12) default NULL,
  `text_align` varchar(20) default NULL,
  `text_deco` varchar(20) default NULL,
  `text_style` varchar(20) default NULL,
  `image_url` varchar(255) default NULL,
  `image_repeat` varchar(20) default NULL,
  PRIMARY KEY  (`widget_id`)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Table structure for table `window_templates`
#

CREATE TABLE `window_templates` (
  `window_id` varchar(20) NOT NULL default '',
  `template` text NOT NULL,
  PRIMARY KEY  (`window_id`)
) TYPE=MyISAM;
